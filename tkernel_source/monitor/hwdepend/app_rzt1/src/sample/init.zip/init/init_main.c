/*******************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2015 Renesas Electronics Corporation. All rights reserved.
*******************************************************************************/
/*******************************************************************************
* System Name  : RZ/T1 Init program
* File Name    : init_main.c
* Version      : 1.2
* Device       : R7S910017
* Abstract     : Main program for RZ/T1 Init program
* Tool-Chain   : e2studio
* OS           : not use
* H/W Platform : RZ/T1 Evaluation Board (RTK7910022C00000BR)
* Description  : Initialize the peripheral settings of RZ/T1
* Limitation   : none
*******************************************************************************/
/*******************************************************************************
* History      : DD.MM.YYYY Version  Description
*              : 01.07.2015 1.1      First Release
*              : 30.11.2015 1.2      Second Release
*                                     - Add dummy writing to HVA0 register for
*                                       initialization of VIC
*              : 29.02.2016 1.2A     Third Release
*                                     - Ensure data-change of HVA0 register
*******************************************************************************/

/*******************************************************************************
Includes <System Includes> , "Project Includes"
*******************************************************************************/
#include "platform.h"
#include "iodefine.h"
#include "r_system.h"
#include "r_icu_init.h"
#include "r_mpc.h"
#include "r_port.h"
#include "r_ecm.h"

/*******************************************************************************
Macro definitions
*******************************************************************************/

/*******************************************************************************
Typedef definitions
*******************************************************************************/

/*******************************************************************************
Imported global variables and functions (from other files)
*******************************************************************************/

/*******************************************************************************
Exported global variables and functions (to be accessed by other files)
*******************************************************************************/

/*******************************************************************************
Private variables and functions
*******************************************************************************/
int main(void);
void port_init(void);
void ecm_init(void);
void icu_init(void);
void soft_wait(void);
void R_IRQ9_isr(void) __attribute__ ((interrupt));
void R_IRQ16_isr(void) __attribute__ ((interrupt));

/*******************************************************************************
* Outline      : main processing
* Function Name: main
* Description  : Initialize the peripheral settings of RZ/T1.
                 Main processing is toggle output of PF7 (LED0).
* Arguments    : none
* Return Value : none
*******************************************************************************/
int main (void)
{
    /* Initialize the port function */
    port_init();
    
    /* Initialize the ECM function */
    ecm_init();
    
    /* Initialize the ICU settings */
    icu_init();

    
    while (1)
    {
        /* Toggle the PF7 output level(LED0) */
        PORTF.PODR.BIT.B7 ^= 1;
    
        soft_wait();  // Soft wait for blinking LED0
        
    }
   
}
/*******************************************************************************
 End of function main
*******************************************************************************/

/*******************************************************************************
* Function Name: port_init
* Description  : Initialize port setting as following.
*                 PF7 : Output and low level.
*                 P56 : Output and low level.
* Arguments    : none
* Return Value : none
*******************************************************************************/
void port_init(void)
{
    /* Set PF7 to Output port pin (Using LED0) */
    PORTF.PDR.BIT.B7 = PORT_DIRECTION_HIZ;  // Initialize port settings
    PORTF.PMR.BIT.B7 = PORT_MODE_GENERAL;
  
    PORTF.PODR.BIT.B7 = PORT_OUTPUT_LOW;  // Set output level to Low
    PORTF.PDR.BIT.B7 = PORT_DIRECTION_OUTPUT;  // Set port direction to output
    
    
    /* Set P56 to Output port pin (Using LED1) */
    PORT5.PDR.BIT.B6 = PORT_DIRECTION_HIZ;  // Initialize port settings
    PORT5.PMR.BIT.B6 = PORT_MODE_GENERAL;
  
    PORT5.PODR.BIT.B6 = PORT_OUTPUT_LOW;  // Set output level to Low
    PORT5.PDR.BIT.B6 = PORT_DIRECTION_OUTPUT;  // Set port direction to output
}

/*******************************************************************************
 End of function port_init
*******************************************************************************/

/*******************************************************************************
* Function Name: ecm_init
* Description  : Initialize ECM setting as following.
*                  Error 35 : Permit to generate the ECM reset                                
* Arguments    : none
* Return Value : none
*******************************************************************************/
void ecm_init(void)
{
    volatile uint8_t result;
    
    /* Initialize ECM function  */
    R_ECM_Init();
   
    /*******************************************/
    /*      Set extended pseudo error 35       */
    /*******************************************/
    
    /* Enables internal reset configuration */
    result = R_ECM_Write_Reg32(ECM_COMMON, &(ECM.ECMIRCFG1.LONG), 0x00000004);
    
}

/*******************************************************************************
 End of function ecm_init
*******************************************************************************/

/*******************************************************************************
* Function Name: icu_init
* Description  : Initialize Interrupt Controller Unit setting.
* Arguments    : none
* Return Value : none
*******************************************************************************/
void icu_init(void)
{
    /* Initialize VIC (dummy writing to HVA0 register) */
    HVA0_DUMMY_WRITE();

    /*******************************************/
    /*      Set IRQ pin interrupt 5(IRQ9)      */
    /*******************************************/

    R_ICU_Disable( ICU_VEC_NUM_9 );  // Mask IRQ9
    
    /* Set external interrupt pin: pin number, Falling edge, 
    degital noise filter(PCLKB/1) (if IRQ pin is used)  */
 
    R_ICU_ExtPinInit( ICU_EXT_PIN_5, ICU_DETECT_FALL, ICU_DNF_DIVISION_64 );
    
    /* Set multi-function pin controller setting (if IRQ pin is used) */    
    PORTN.PDR.BIT.B5 = PORT_DIRECTION_HIZ;  // Initialize port settings
    PORTN.PMR.BIT.B5 = PORT_MODE_GENERAL;
    
    PORTN.PDR.BIT.B5 = PORT_DIRECTION_INPUT; //Set PN5 to input
    
    R_MPC_WriteEnable();  // Enables writing to the PFS register 
    MPC.PN5PFS.BIT.ISEL = MPC_IRQ_ENABLE ;  // Set PN5PFS.ISEL bit to 1.
    R_MPC_WriteDisable();  // Disables writing to the PFS register
    
    /* Set VIC setting: vector number, detection type, priority level */
    /* Casting the ISR to a (uint32_t) is valid because this ISR will
    be located in 32 bit memory map address */
    R_ICU_Regist( ICU_VEC_NUM_9, ICU_TYPE_EDGE, ICU_PRIORITY_15, (uint32_t) R_IRQ9_isr );
    
    R_ICU_Enable( ICU_VEC_NUM_9 );  // Enable IRQ9

    /**********************************************/
    /*      Set IRQ pin interrupt 12 (IRQ16)      */
    /**********************************************/
    
    R_ICU_Disable( ICU_VEC_NUM_16 );  // Mask IRQ16

    /* Set external interrupt pin: pin number, Falling edge,
       degital noise filter(PCLKB/1) (if IRQ pin is used)  */

    R_ICU_ExtPinInit( ICU_EXT_PIN_12, ICU_DETECT_FALL, ICU_DNF_DIVISION_64 );

    /* Set multi-function pin controller setting (if IRQ pin is used) */
    PORT4.PDR.BIT.B4 = PORT_DIRECTION_HIZ;  // Initialize port settings
    PORT4.PMR.BIT.B4 = PORT_MODE_GENERAL;
    
    PORT4.PDR.BIT.B4 = PORT_DIRECTION_INPUT; //Set P44 to input
    
    R_MPC_WriteEnable();  // Enables writing to the PFS register 
    MPC.P44PFS.BIT.ISEL = MPC_IRQ_ENABLE ;  // Set P44PFS.ISEL bit to 1.
    R_MPC_WriteDisable();  // Disables writing to the PFS register
    
    /* Set VIC setting: vector number, detection type, priority level */
    /* Casting the ISR to a (uint32_t) is valid because this ISR will
       be located in 32 bit memory map address */
    R_ICU_Regist( ICU_VEC_NUM_16, ICU_TYPE_EDGE, ICU_PRIORITY_15, (uint32_t) R_IRQ16_isr );
    
    R_ICU_Enable( ICU_VEC_NUM_16 );  // Enable IRQ16
    
    
    /* Enable IRQ interrupt (Clear CPSR.I bit to 0) */
    asm("cpsie i");   // Clear CPSR.I bit to 0 
    asm("isb");       // Ensuring Context-changing
    
}

/*******************************************************************************
 End of function icu_init
*******************************************************************************/

/*******************************************************************************
* Function Name: soft_wait
* Description  : soft wait function using NOP 
* Arguments    : none
* Return Value : none
*******************************************************************************/
void soft_wait(void)
{
    uint32_t loop;
    
    for (loop = 0; loop < 10000000 ; loop++ )  
    {
        asm("nop");  
    }
    
}

/*******************************************************************************
 End of function soft_wait
*******************************************************************************/

/*******************************************************************************
* Function Name: R_IRQ9_isr
* Description  : Interrupt service routine of IRQ9 (IRQ5 pin interrupt).
*                Toggle the P56 output level (LED1)
* Arguments    : none
* Return Value : none
*******************************************************************************/
void R_IRQ9_isr(void)
{
    /* Clear interrupt edge detection */  
    VIC.PIC0.BIT.PIC9 = ICU_PIC_EDGE_CLEAR; 
  
    /* Toggle the P56 output level(LED1) */
    PORT5.PODR.BIT.B6 ^= 1;
        
    /* End interrupt sequence (dummy writing to HVA0 register) */
    HVA0_DUMMY_WRITE();
  
}

/*******************************************************************************
 End of function R_IRQ9_isr
*******************************************************************************/

/*******************************************************************************
* Function Name: R_IRQ16_isr
* Description  : Interrupt service routine of IRQ16 (IRQ12 pin interrupt).
*                Generate extended pseudo error 35 (ECM reset). And set P77
*                output level to High (LED2) after reset.
* Arguments    : none
* Return Value : none
*******************************************************************************/
void R_IRQ16_isr(void)
{
    /* Clear interrupt edge detection */
    VIC.PIC0.BIT.PIC16 = ICU_PIC_EDGE_CLEAR;

    /* Generate extended pseudo error 35 */
    /* Sets extended pseudo error 35 trigger */
    R_ECM_Write_Reg32(ECM_COMMON, &(ECM.ECMPE1.LONG), 0x00000004);

    /* Caution : Because ECM reset will be generated,
                 the following sequence is not described */

}

/*******************************************************************************
 End of function R_IRQ16_isr
*******************************************************************************/

/* End of File */
