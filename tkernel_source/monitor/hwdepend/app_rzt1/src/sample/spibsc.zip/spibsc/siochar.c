/*******************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
* Copyright (C) 2016 Renesas Electronics Corporation. All rights reserved.
*******************************************************************************/
/*******************************************************************************
* System Name  : RZ/T1 SCIF program
* File Name    : siochar.c
* Version      : 1.1
* Device       : R7S910017
* Abstract     : Serial I/O settings controlling the character
* Tool-Chain   : e2studio
* OS           : not use
* H/W Platform : RZ/T1 Evaluation Board (RTK7910022C00000BR)
* Description  : Control the character with serial I/O  
* Limitation   : none
*******************************************************************************/
/*******************************************************************************
* History      : DD.MM.YYYY Version  Description
*              : 22.12.2015 1.0      First Release
*              : 18.03.2016 1.1      Second Release
*******************************************************************************/

/*******************************************************************************
Includes   <System Includes> , "Project Includes"
*******************************************************************************/
#include "platform.h"
#include "r_system.h"
#include "r_scifa_uart.h"
#include "sio_char.h"


/*******************************************************************************
Typedef definitions
*******************************************************************************/


/*******************************************************************************
Macro definitions
*******************************************************************************/


/*******************************************************************************
Imported global variables and functions (from other files)
*******************************************************************************/


/*******************************************************************************
Exported global variables and functions (to be accessed by other files)
*******************************************************************************/


/*******************************************************************************
Private global variables and functions
*******************************************************************************/


/*******************************************************************************
* Function Name: IoInitScifa2
* Description  : This function initializes SCIFA channel 2 as UART mode.
*              : The transmit and the receive of SCIFA channel 2 are enabled.
* Arguments    : none
* Return Value : none
*******************************************************************************/
void IoInitScifa2 (void)
{
    /* === Initialization of SCIFA2 ==== */
    /* SERICLK=150MHz CKS=0 BRR=40 Bit rate error=-0.76% => Baud rate=115200bps */
    R_SCIFA_UART_Init(SCIFA_UART_CH_2, SCIFA_UART_MODE_RW, SCIFA_UART_CKS_DIVISION_1, 40);

    /* === Enable SCIFA2 transmission/reception ==== */
    R_SCIFA_UART_Open(SCIFA_UART_CH_2, SCIFA_UART_MODE_RW);
}

/*******************************************************************************
* Function Name: IoGetchar
* Description  : One character is received from SCIFA2, and it's data is returned.
*              : This function keeps waiting until it can obtain the receiving data.
* Arguments    : none
* Return Value : Character to receive (Byte).
*******************************************************************************/
int32_t IoGetchar (void)
{
    int32_t    data;
    uint8_t    data_char;

    if( R_SCIFA_UART_Receive(SCIFA_UART_CH_2, &data_char) < SCIFA_UART_SUCCESS )
    {
        return -1;
    }

    data = (int32_t)(data_char &0xff);

    return data;
}

/*******************************************************************************
* Function Name: IoPutchar
* Description  : Character "buffer" is output to SCIFA2.
*              : This function keeps waiting until it becomes the transmission
*              : enabled state.
* Arguments    : int_t buffer : character to output
* Return Value : None
*******************************************************************************/
void IoPutchar (int32_t buffer)
{
    R_SCIFA_UART_Send(SCIFA_UART_CH_2, (uint8_t)buffer);
}


/* End of File */

