/*******************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
* Copyright (C) 2016 Renesas Electronics Corporation. All rights reserved.
*******************************************************************************/
/*******************************************************************************
* System Name  : RZ/T1 SCIF program
* File Name    : siorw.c
* Version      : 1.1
* Device       : R7S910017
* Abstract     : Serial I/O settings controlling the read and write command
* Tool-Chain   : e2studio
* OS           : not use
* H/W Platform : RZ/T1 Evaluation Board (RTK7910022C00000BR)
* Description  : Control the read/write command with serial I/O  
* Limitation   : none
*******************************************************************************/
/*******************************************************************************
* History      : DD.MM.YYYY Version  Description
*              : 22.12.2015 1.0      First Release
*              : 18.03.2016 1.1      Second Release
*******************************************************************************/


/*******************************************************************************
Includes   <System Includes> , "Project Includes"
*******************************************************************************/
#include <stdio.h>
#include "platform.h"
#include "r_system.h"
#include "sio_char.h"

#ifdef __ICCARM__
  #include <yfuns.h>
  _STD_BEGIN
  #pragma module_name = "?__write"
#endif

/*******************************************************************************
Typedef definitions
*******************************************************************************/


/*******************************************************************************
Macro definitions
*******************************************************************************/
/* File descriptor */
#ifndef __ICCARM__
  #define STDIN           (0)
  #define STDOUT          (1)
  #define STDERR          (2)
#endif

#define SIORW_SUCCESS   (0)
#define SIORW_ERROR     (-1)
#define SIORW_FLAG_OFF  (0)
#define SIORW_FLAG_ON   (1)


/*******************************************************************************
Imported global variables and functions (from other files)
*******************************************************************************/


/*******************************************************************************
Exported global variables and functions (to be accessed by other files)
*******************************************************************************/


/*******************************************************************************
Private global variables and functions
*******************************************************************************/


/*******************************************************************************
* Function Name: SioWrite
* Description  : The character strings specified with buffer is output for n
*              : bytes from serial port. The output is determined by file number fileno.
*              : The effective outputs in this version are STDOUT and STDERR, and
*              : it is output to the same serial port.
*              : The linefeed code '\n'(LF) is converted in '\r'(CR)+'\n'(LF) to output.
* Arguments    : int32_t  file_no  ; I : File number to be the target of writing
*              : int_t  * buffer   ; O : Pointer to the area in which writing data is stored
*              : uint32_t writing_b; I : Writing bytes
* Return Value : >=0 : Number of transmitting characters
*              : -1  : File number error
*******************************************************************************/
int _write(int file,char *ptr,int len)
{
    return (SioWrite(file,ptr,len));
}

#ifndef __ICCARM__
  int32_t SioWrite(int32_t file_no, const char_t * buffer, uint32_t writing_b)
#else
  size_t __write(int handle, const unsigned char * buffer, size_t size)
#endif
{
    uint32_t offset;

#ifndef __ICCARM__
    if ((STDOUT == file_no) || (STDERR == file_no))
    {
        for (offset = 0; offset < writing_b; offset++)
#else
    if ((_LLIO_STDOUT == handle) && (_LLIO_STDERR != handle))
    {
        for (offset = 0; offset < size; offset++)
#endif
        {
            /* Writing in buffer converting linefeed code */
            if ('\n' == *(buffer + offset))
            {
                if (0 == offset)
                {
                    IoPutchar('\r');
                }
                else
                {
                    if (*(buffer + offset - 1) != '\r')
                    {
                        IoPutchar('\r');
                    }
                }
                IoPutchar('\n');
            }
            else
            {
                IoPutchar(*(buffer + offset));
            }
        }
        return (int32_t)offset;
    }

#ifndef __ICCARM__
    return SIORW_ERROR;     /* File number error */
#else
    return _LLIO_ERROR;     /* File number error */
#endif
}

/*******************************************************************************
* Function Name: SioRead
* Description  : The character strings specified with buffer is input for
*              : n bytes from serial port.The input is determined by file number fileno.
*              : The effective input in this version is STDIN.
* Arguments    : int32_t  file_no  ; I : File number to be the target of reading
*              : int_t  * buffer   ; O : Pointer to the area in which reading data is stored
*              : uint32_t reading_b; I : Reading bytes
* Return Value : >0 : Number of receiving characters
*              : -1 : File number, receiving data error
*******************************************************************************/
int _read (int file, char *ptr, int len)
{
    return (SioRead(file,ptr,len));
}

#ifndef __ICCARM__
  int32_t SioRead(int32_t file_no, char_t * buffer, uint32_t reading_b)
#else
  size_t __read(int handle, unsigned char * buffer, size_t size)
#endif
{
    int32_t        char_mem;
    int32_t        sp_char;
    uint32_t       offset;
    static int32_t sjis_flg = SIORW_FLAG_OFF;

#ifndef __ICCARM__
    if (STDIN == file_no)
    {
        for (offset = 0; offset < reading_b; )
#else
    if (_LLIO_STDIN == handle)
    {
        for (offset = 0; offset < size; )
#endif
        {
            /* Reading receiving data */
            char_mem = IoGetchar();

            if (-1 == char_mem)   /* -1 is returned when it is receiving data error */
            {
                return SIORW_ERROR;
            }

            if (SIORW_FLAG_ON == sjis_flg)
            {
                sjis_flg = SIORW_FLAG_OFF;
#ifndef __ICCARM__
                SioWrite(STDOUT, (char_t *)&char_mem, 1);
#else
                __write(_LLIO_STDOUT, (const unsigned char *)&char_mem, 1);
#endif
                *(buffer + offset) = char_mem;
                offset++;
            }
            else if ((0x20 <= char_mem) && (char_mem <= 0x7E))
            {
                /* Data possible to display */
#ifndef __ICCARM__
                SioWrite(STDOUT, (char_t *)&char_mem, 1);
#else
                __write(_LLIO_STDOUT, (const unsigned char *)&char_mem, 1);
#endif
                *(buffer + offset) = char_mem;
                offset++;
            }
            else if ('\b' == char_mem)      /* BS process */
            {
                if (offset > 0)
                {
                    sp_char = 0x20;
#ifndef __ICCARM__
                    SioWrite(STDOUT, (char_t *)&char_mem, 1);
                    SioWrite(STDOUT, (char_t *)&sp_char, 1);
                    SioWrite(STDOUT, (char_t *)&char_mem, 1);
#else
                    __write(_LLIO_STDOUT, (const unsigned char *)&char_mem, 1);
                    __write(_LLIO_STDOUT, (const unsigned char *)&sp_char, 1);
                    __write(_LLIO_STDOUT, (const unsigned char *)&char_mem, 1);
#endif
                    offset--;
                }
            }
            else if ('\r' == char_mem)      /* CR process */
            {
                *(buffer + offset) = '\n';
#ifndef __ICCARM__
                SioWrite(STDOUT, buffer + offset, 1);
#else
                __write(_LLIO_STDOUT, (const unsigned char*)(buffer + offset), 1);
#endif
                offset++;
                break;
            }
            /* Japanese SJIS ? */
            else if (((char_mem >= 0x80) && (char_mem < 0xA0)) || ((char_mem >= 0xE0) && (char_mem < 0xFE)))
            {
                /* Data possible to display */
#ifndef __ICCARM__
                SioWrite(STDOUT, (char_t *)&char_mem, 1);
#else
                __write(_LLIO_STDOUT, (const unsigned char*)&char_mem, 1);
#endif
                *(buffer + offset) = char_mem;
                offset++;
                sjis_flg = SIORW_FLAG_ON;
            }
            /* Character cord out of the support */
            else
            {
                /* Do Nothing */
            }
        }
        return (int32_t)offset;
    }

#ifndef __ICCARM__
    return SIORW_ERROR;     /* File number error */
#else
    return _LLIO_ERROR;     /* File number error */
#endif
}

#ifdef __ICCARM__
  _STD_END
#endif

/* End of File */

